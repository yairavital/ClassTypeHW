﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractEX9
{
    class Program
    {
  static void Main(string[] args)
    {
            VeihcleBase car1 = new Car(2);
            VeihcleBase motorcyclecs1 = new Motorcyclecs(3);
            VeihcleBase car2 = new Car(4);
            VeihcleBase motorcyclecs2 = new Motorcyclecs(4);
            VeihcleBase car3 = new Car(2);
            VeihcleBase motorcyclecs3 = new Motorcyclecs(2);
            VeihcleBase[] v = new VeihcleBase[] { car1, car2, car3, motorcyclecs1, motorcyclecs2, 
                motorcyclecs3 }; 
            Carrier carrier1 = new Carrier(v);
            foreach (VeihcleBase veihcle in carrier1.Veihcles)
            {
                Console.WriteLine(veihcle.ToString());
            }
        }
    }


  

}
