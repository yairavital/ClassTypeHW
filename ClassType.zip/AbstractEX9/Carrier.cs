﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractEX9
{
    public class Carrier
    {
       public VeihcleBase [] Veihcles { get; set; }
        public Carrier( VeihcleBase [] v)
        {
            Veihcles = v;

        }
        public override string ToString()
        {
            string ss = "";
            foreach (VeihcleBase v in Veihcles)
            {
               ss+= v.ToString() + "\n";
            }
            return ss;
        }
    }
}
