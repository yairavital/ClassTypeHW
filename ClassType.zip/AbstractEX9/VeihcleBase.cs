﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractEX9
{
    public abstract class VeihcleBase
    {
        public int NumberOfWeels { get; set; }
        public string Model { get; set; }
        public abstract void GetMaxNumOfPassangers();
        public abstract void GetMaxSpeed();
        public override string ToString()
        {
            return $"the number of whells are {NumberOfWeels} and the model is {Model}";
        }


    }
}
