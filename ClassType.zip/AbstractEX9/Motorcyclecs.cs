﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractEX9
{
    internal class Motorcyclecs : VeihcleBase
    {
        public int NumberOfHandBrakes { get; set; }
        public Motorcyclecs(int num2)
        {
            NumberOfHandBrakes = num2;
        }
        public override void GetMaxNumOfPassangers()
        {
            Console.WriteLine("The max num of passangers in motorcycle is 2");
        }

        public override void GetMaxSpeed()
        {
            Console.WriteLine("The maximum speed in the motorocycle is 150km / h");
        }
        public override string ToString()
        {
            return base.ToString() + NumberOfHandBrakes;
        }
    }
}
