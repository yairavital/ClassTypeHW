﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractEX9
{
    internal class Car : VeihcleBase
    {
        public int NumberOfDoors { get; set; }
        public Car(int num)
        {
            NumberOfDoors = num;
        }
        public override void GetMaxNumOfPassangers()
        {
            Console.WriteLine("The max num of passangers in car is 5");
            
        }

        public override void GetMaxSpeed()
        {
            Console.WriteLine("The maximum speed in the car is 200 km / h");
        }
        public override string ToString()
        {
            return base.ToString() + NumberOfDoors;
        }
    }
}
